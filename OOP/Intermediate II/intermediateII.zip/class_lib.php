<?php 

class animal
{

	

}
?>
