<?php include('class_lib.php'); 

$car1 = new car(100000, '35mph', 'Not full', '15mpg');

$car1->Display_all();
?>